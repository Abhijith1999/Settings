*************************
File provide You Black BOY
**************************

internal and external Storage  fix for lenovo A5000

flash this zip file through twrp recovery

or 

copy storage.xml
to
"/data/system" folder




After reboot phone,you Have to setup Sdcard.(otherwise apps can't detect sdcard)
you can use sdcard either internal or external storage.using sdcard as internal ,you need to format sdcard.
